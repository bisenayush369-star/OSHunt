import type { Metadata, Viewport } from "next";
import "./globals.css";
import SessionWrapper from "@/components/SessionWrapper";
import ConditionalFooter from "@/components/ui/ConditionalFooter";
import { AppBottomNav } from "@/components/ui/app-bottom-nav";
import { UsageLimitWarning } from "@/components/ui/warning";
import { BookmarkToaster } from "@/components/bookmarks/BookmarkToaster";
import { auth } from "@/components/lib/auth";

export const dynamic = "force-dynamic";

// Note: removed `next/font/google` import to avoid remote fetch during build in offline environments.
// The app falls back to system fonts defined in `globals.css`.

export const metadata: Metadata = {
  title: "OSHunt — Find bugs. Fix them. Get known.",
  description: "AI-powered open source contribution platform",
  icons: {
    icon: "/favicon.png"
  },
};

export const viewport: Viewport = {
  viewportFit: "cover",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const session = await auth();

  return (
    <html lang="en">
      <body>
        <SessionWrapper session={session}>
          <UsageLimitWarning />
          <ConditionalFooter>{children}</ConditionalFooter>
          <AppBottomNav />
          <BookmarkToaster />
        </SessionWrapper>
      </body>
    </html>
  );
}